<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateRecruitmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('recruitments', function (Blueprint $table) {
            $table->id();
            $table->string('name');
            $table->string('description');
            $table->unsignedBigInteger('producer_id');
            $table->foreign('producer_id')->references('id')->on('users');
            $table->string('workplace');
            $table->string('reward');
            $table->string('work_time');
            $table->string('break_time');
            $table->boolean('lunch_mode');
            $table->string('pay_mode');
            $table->string('applicants');
            $table->string('traffic_cost');
            $table->boolean('with_rain');
            $table->string('clothes');
            $table->string('belongings');
            $table->boolean('toilet');
            $table->boolean('park');
            $table->boolean('insurance');
            $table->string('notice');
            $table->string('image');
            $table->enum('status', ['draft', 'being', 'contracted', 'completed']);
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('recruitments');
    }
}
