<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->id();
            // fields for auth
            $table->string('email')->unique();
            $table->timestamp('email_verified_at')->nullable();
            $table->string('password');
            $table->enum('role', ['producer', 'worker']);

            // fields for profile
            $table->string('avatar');
            $table->string('family_name');
            $table->string('name');
            $table->string('nickname');
            $table->enum('gender', ['man', 'woman']);
            $table->date('birthday');
            $table->string('address');
            $table->string('contact_address');
            $table->string('cell_phone');
            $table->string('emergency_phone');
            $table->string('emergency_relation');
            $table->string('job');
            $table->string('bio');
            $table->string('appeal_point');

            // fields for producer
            $table->string('management_mode');
            $table->string('agency_name');
            $table->string('agency_phone');
            $table->boolean('insurance');
            $table->string('other_insurance');
            $table->string('product_name');

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
